package com.example.notes_app_bloc

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
